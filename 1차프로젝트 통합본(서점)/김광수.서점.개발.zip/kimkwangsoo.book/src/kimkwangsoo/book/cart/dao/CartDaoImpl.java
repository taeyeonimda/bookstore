package kimkwangsoo.book.cart.dao;

import java.util.List;

import kimkwangsoo.book.cart.dao.map.CartMap;
import kimkwangsoo.book.cart.domain.Cart;
import kimkwangsoo.book.config.Configuration;

public class CartDaoImpl implements CartDao {
	private CartMap cartMap;
	
	public CartDaoImpl() {
		this.cartMap = Configuration.getMapper(CartMap.class);
	}
	
	@Override
	public Integer getBooksCount(int bookIsbn) {
		return this.cartMap.getBooksCount(bookIsbn);
	}
	
	@Override
	public Cart getCart(int cartNum) {
		return this.cartMap.getCart(cartNum);
	}
	
	@Override
	public List<Cart> getCarts(String userId) {
		return this.cartMap.getCarts(userId);
	}
	
	@Override
	public void addCart(Cart cart) {
		this.cartMap.addCart(cart);
	}
	
	@Override
	public void updateCart(Cart cart) {
		this.cartMap.updateCart(cart);
	}
	
	@Override
	public void deleteCart(int cartNum) {
		this.cartMap.deleteCart(cartNum);
	}
}
