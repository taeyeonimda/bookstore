package kimkwangsoo.book.user.dao.map;

import java.util.List;

import kimkwangsoo.book.page.domain.Page;
import kimkwangsoo.book.user.domain.User;

public interface UserMap {
	User getUser(String userId);
	List<User> getUsers(Page page);
	void addUser(User user);
	void updateUser(User user);
	void deleteUser(User user);
}
