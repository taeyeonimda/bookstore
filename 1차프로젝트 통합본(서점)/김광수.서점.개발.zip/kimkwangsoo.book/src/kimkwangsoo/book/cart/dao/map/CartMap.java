package kimkwangsoo.book.cart.dao.map;

import java.util.List;

import kimkwangsoo.book.cart.domain.Cart;

public interface CartMap {
	Integer getBooksCount(int bookIsbn);
	Cart getCart(int cartNum);
	List<Cart> getCarts(String userId);
	void addCart(Cart cart);
	void updateCart(Cart cart);
	void deleteCart(int cartNum);
}
