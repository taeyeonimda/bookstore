package kimkwangsoo.book.book.dao.map;

import java.util.List;

import kimkwangsoo.book.book.domain.Book;
import kimkwangsoo.book.page.domain.Page;

public interface BookMap {
	Book getBook(int bookIsbn);
	List<Book> getBooks(Page page);
	// List<Book> searchBooks(String words);
	List<Book> searchBooks(Page page);
	int addBook(Book book);
	void updateBook(Book book);
	void updateBookStatus(int bookIsbn);
	void deleteBook(int bookIsbn);
}
