package kimkwangsoo.book.page.dao;

public interface PageDao {
	int getUsersTotRowCnt();
	int getBooksTotRowCnt();
	int getSearchBooksTotRowCnt(String words);
	int getOrdersTotRowCnt(String userId);
	int getCartsTotRowCnt();
}
