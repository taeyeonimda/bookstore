package kimkwangsoo.book.page.service;

import kimkwangsoo.book.page.domain.Page;

public interface PageService {
	Page getPage();
	boolean isPrev();
	boolean isNext();
	int getStartPage();
	int getEndPage();
}
