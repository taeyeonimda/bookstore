package kimkwangsoo.book.user.service;

import java.util.List;

import kimkwangsoo.book.page.domain.Page;
import kimkwangsoo.book.user.domain.User;

public interface UserService {
	User getUser(String userId);
	List<User> getUsers(Page page);
	void addUser(User user);
	void updateUser(User user);
	void deleteUser(User user);
}
