package kimkwangsoo.book.cart.service;

import java.util.List;

import kimkwangsoo.book.cart.dao.CartDao;
import kimkwangsoo.book.cart.dao.CartDaoImpl;
import kimkwangsoo.book.cart.domain.Cart;

public class CartServiceImpl implements CartService {
	private CartDao cartDao;
	
	public CartServiceImpl() {
		this.cartDao = new CartDaoImpl();
	}
	
	@Override
	public Integer getBooksCount(int bookIsbn) {
		return this.cartDao.getBooksCount(bookIsbn);
	}
	
	@Override
	public Cart getCart(int cartNum) {
		return this.cartDao.getCart(cartNum);
	}
	
	@Override
	public List<Cart> getCarts(String userId) {
		return this.cartDao.getCarts(userId);
	}
	
	@Override
	public void addCart(Cart cart) {
		this.cartDao.addCart(cart);
	}
	
	@Override
	public void updateCart(Cart cart) {
		this.cartDao.updateCart(cart);
	}
	
	@Override
	public void deleteCart(int cartNum) {
		this.cartDao.deleteCart(cartNum);
	}
}
