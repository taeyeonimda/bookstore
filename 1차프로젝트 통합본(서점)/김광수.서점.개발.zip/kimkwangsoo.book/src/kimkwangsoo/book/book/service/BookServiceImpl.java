package kimkwangsoo.book.book.service;

import java.util.List;

import kimkwangsoo.book.book.dao.BookDao;
import kimkwangsoo.book.book.dao.BookDaoImpl;
import kimkwangsoo.book.book.domain.Book;
import kimkwangsoo.book.page.domain.Page;

public class BookServiceImpl implements BookService {
	private BookDao bookDao;
	
	public BookServiceImpl() {
		this.bookDao = new BookDaoImpl();
	}
	
	@Override
	public Book getBook(int bookIsbn) {
		return this.bookDao.getBook(bookIsbn);
	}
	
	@Override
	public List<Book> getBooks(Page page) {
		return this.bookDao.getBooks(page);
	}
	
	@Override
	public List<Book> searchBooks(Page page) {
		return this.bookDao.searchBooks(page);
	}
	
	@Override
	public int addBook(Book book) {
		return this.bookDao.addBook(book);
	}
	
	@Override
	public void updateBook(Book book) {
		this.bookDao.updateBook(book);
	}
	
	@Override
	public void updateBookStatus(int bookIsbn) {
		this.bookDao.updateBookStatus(bookIsbn);
	}
	
	@Override
	public void deleteBook(int bookIsbn) {
		this.bookDao.deleteBook(bookIsbn);
	}
}
