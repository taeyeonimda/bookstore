package kimkwangsoo.book.book.domain;

import java.sql.Date;

public class Book {
	private int bookIsbn;
	private String bookTitle;
	private int bookPrice;
	private String bookAuthor;
	private String bookPublisher;
	private Date bookPublishDate;
	private String bookIntr;
	private String bookGenre;
	private String bookImage;
	private char bookStatus;
	
	public Book() {

	}
	
	public Book(int bookIsbn, String bookTitle) {
		this.bookIsbn = bookIsbn;
		this.bookTitle = bookTitle;
	}

	
	public int getBookIsbn() {
		return bookIsbn;
	}
	
	public void setBookIsbn(int bookIsbn) {
		this.bookIsbn = bookIsbn;
	}
	
	public String getBookTitle() {
		return bookTitle;
	}
	
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	
	public int getBookPrice() {
		return bookPrice;
	}
	
	public void setBookPrice(int bookPrice) {
		this.bookPrice = bookPrice;
	}
	
	public String getBookAuthor() {
		return bookAuthor;
	}

	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}

	public String getBookPublisher() {
		return bookPublisher;
	}

	public void setBookPublisher(String bookPublisher) {
		this.bookPublisher = bookPublisher;
	}

	public Date getBookPublishDate() {
		return bookPublishDate;
	}

	public void setBookPublishDate(Date bookPublishDate) {
		this.bookPublishDate = bookPublishDate;
	}

	public String getBookIntr() {
		return bookIntr;
	}

	public void setBookIntr(String bookIntr) {
		this.bookIntr = bookIntr;
	}

	public String getBookGenre() {
		return bookGenre;
	}

	public void setBookGenre(String bookGenre) {
		this.bookGenre = bookGenre;
	}

	public String getBookImage() {
		return bookImage;
	}

	public void setBookImage(String bookImage) {
		this.bookImage = bookImage;
	}

	public char getBookStatus() {
		return bookStatus;
	}

	public void setBookStatus(char bookStatus) {
		this.bookStatus = bookStatus;
	}

	@Override
	public String toString() {
		return String.format("[%d %-6s %s %s %s %s %s %s %d]", bookIsbn, bookTitle, bookAuthor, bookPublisher,
				bookPublishDate, bookIntr, bookGenre, bookImage, bookPrice);
	}
}
