package kimkwangsoo.book.page.dao;

import kimkwangsoo.book.config.Configuration;
import kimkwangsoo.book.page.dao.map.PageMap;

public class PageDaoImpl implements PageDao {
	private PageMap pageMapper;
	
	public PageDaoImpl() {
		this.pageMapper = Configuration.getMapper(PageMap.class);
	}
	
	@Override
	public int getUsersTotRowCnt() {
		return pageMapper.getUsersTotRowCnt();
	}
	
	@Override
	public int getBooksTotRowCnt() {
		return pageMapper.getBooksTotRowCnt();
	}
	
	@Override
	public int getSearchBooksTotRowCnt(String words) {
		return pageMapper.getSearchBooksTotRowCnt(words);
	}
	
	@Override
	public int getOrdersTotRowCnt(String userId) {
		return pageMapper.getOrdersTotRowCnt(userId);
	}
	
	@Override
	public int getCartsTotRowCnt() {
		return pageMapper.getCartsTotRowCnt();
	}
}
