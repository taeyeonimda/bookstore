package kimkwangsoo.book.cart.dao;

import java.util.List;

import kimkwangsoo.book.cart.domain.Cart;

public interface CartDao {
	Integer getBooksCount(int bookIsbn);
	Cart getCart(int cartNum);
	List<Cart> getCarts(String userId);
	void addCart(Cart cart);
	void updateCart(Cart cart);
	void deleteCart(int cartNum);
}
