package kimkwangsoo.book.page.service;

import kimkwangsoo.book.page.dao.PageDao;
import kimkwangsoo.book.page.dao.PageDaoImpl;
import kimkwangsoo.book.page.domain.Page;

public class PageServiceImpl implements PageService {
	private PageDao pageDao;
	
	private int startPage;
	private int endPage;
	private boolean prev;
	private boolean next;
	private int usersTotRowCnt;
	private int booksTotRowCnt;
	private int searchBooksTotRowCnt;
	private int ordersTotRowCnt;
	private int pageNumCnt;
	private Page page;
	
	public PageServiceImpl(int pageNumCnt, Page page, int pageType) {
		this.pageDao = new PageDaoImpl();
		this.usersTotRowCnt = getUsersTotRowCnt();
		this.booksTotRowCnt = getBooksTotRowCnt();
		this.pageNumCnt = pageNumCnt;
		this.page = page;
		
		endPage = (int)(Math.ceil(page.getCurrentPage()/(double)pageNumCnt)*pageNumCnt);
		startPage = (endPage-pageNumCnt) + 1;
		int lastEndPage = 0;
		
		switch(pageType) {
		case 1:
			lastEndPage = (int)(Math.ceil(usersTotRowCnt/(double)page.getRowCnt()));
			break;
		case 2:
			lastEndPage = (int)(Math.ceil(booksTotRowCnt/(double)page.getRowCnt()));
			break;
		}
		
		if(endPage > lastEndPage)
			endPage = lastEndPage;
		
		prev = startPage==1 ? false : true;
		switch(pageType) {
		case 1:
			next = endPage * page.getRowCnt() >= usersTotRowCnt ? false : true;
			break;
		case 2:
			next = endPage * page.getRowCnt() >= booksTotRowCnt ? false : true;
			break;
		}
	}
	
	public PageServiceImpl(int pageNumCnt, Page page, int pageType, String str) {
		this.pageDao = new PageDaoImpl();
		this.searchBooksTotRowCnt = getSearchBooksTotRowCnt(str);
		this.ordersTotRowCnt = getOrdersTotRowCnt(str);
		this.pageNumCnt = pageNumCnt;
		this.page = page;
		
		endPage = (int)(Math.ceil(page.getCurrentPage()/(double)pageNumCnt)*pageNumCnt);
		startPage = (endPage-pageNumCnt) + 1;
		int lastEndPage = 0;
		
		switch(pageType) {
		case 3:
			lastEndPage = (int)(Math.ceil(ordersTotRowCnt/(double)page.getRowCnt()));
			break;
		
		case 4:
			lastEndPage = (int)(Math.ceil(searchBooksTotRowCnt/(double)page.getRowCnt()));
			break;
		}
			
		if(endPage > lastEndPage)
			endPage = lastEndPage;
		
		prev = startPage==1 ? false : true;
		switch(pageType) {
		case 3:
			next = endPage * page.getRowCnt() >= ordersTotRowCnt ? false : true;
			break;
			
		case 4:
			next = endPage * page.getRowCnt() >= searchBooksTotRowCnt ? false : true;
			break;
		}
	}
	
	private int getUsersTotRowCnt() {
		return pageDao.getUsersTotRowCnt();
	}
	
	private int getBooksTotRowCnt() {
		return pageDao.getBooksTotRowCnt();
	}
	
	private int getSearchBooksTotRowCnt(String words) {
		return pageDao.getSearchBooksTotRowCnt(words);
	}
	
	private int getOrdersTotRowCnt(String userId) {
		return pageDao.getOrdersTotRowCnt(userId);
	}
	
	public Page getPage() {
		return page;
	}
	
	public boolean isPrev() {
		return prev;
	}
	
	public boolean isNext() {
		return next;
	}
	
	public int getStartPage() {
		return startPage;
	}
	
	public int getEndPage() {
		return endPage;
	}
}
