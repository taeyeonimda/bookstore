package kimkwangsoo.book.order.domain;

import java.sql.Date;
import java.util.List;

import kimkwangsoo.book.book.domain.Book;


public class Order {
	private int orderNum;
	private String userId;
	private int bookIsbn;
	private char payType;
	private String recipientName;
	private String recipientAddr;
	private String recipientTel;
	private char orderStatus;
	private Date orderDate;
	private int bookQuan;
	private List<Book> books;

	public int getOrderNum() {
		return orderNum;
	}
	
	public void setOrderNum(int orderNum) {
		this.orderNum = orderNum;
	}
	
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public int getBookIsbn() {
		return bookIsbn;
	}
	
	public void setBookIsbn(int bookIsbn) {
		this.bookIsbn = bookIsbn;
	}
	
	public char getPayType() {
		return payType;
	}
	
	public void setPayType(char payType) {
		this.payType = payType;
	}
	
	public String getRecipientName() {
		return recipientName;
	}
	
	public void setRecipientName(String recipientName) {
		this.recipientName = recipientName;
	}

	public String getRecipientAddr() {
		return recipientAddr;
	}

	public void setRecipientAddr(String recipientAddr) {
		this.recipientAddr = recipientAddr;
	}
	
	public String getRecipientTel() {
		return recipientTel;
	}

	public void setRecipientTel(String recipientTel) {
		this.recipientTel = recipientTel;
	}

	public char getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(char orderStatus) {
		this.orderStatus = orderStatus;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public int getBookQuan() {
		return bookQuan;
	}

	public void setBookQuan(int bookQuan) {
		this.bookQuan = bookQuan;
	}

	public List<Book> getBooks() {
		return books;
	}

	public void setBooks(List<Book> books) {
		this.books = books;
	}

	public String toString() {
		return orderNum + " " + userId + " " + bookIsbn + " " + books + " " + recipientName;
	}
}
