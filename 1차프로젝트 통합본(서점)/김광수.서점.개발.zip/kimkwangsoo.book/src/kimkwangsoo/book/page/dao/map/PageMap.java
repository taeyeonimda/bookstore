package kimkwangsoo.book.page.dao.map;

public interface PageMap {
	int getUsersTotRowCnt();
	int getBooksTotRowCnt();
	int getSearchBooksTotRowCnt(String words);
	int getOrdersTotRowCnt(String userId);
	int getCartsTotRowCnt();
}
