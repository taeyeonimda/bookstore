package kimkwangsoo.book.book.dao;

import java.util.List;

import kimkwangsoo.book.book.dao.map.BookMap;
import kimkwangsoo.book.book.domain.Book;
import kimkwangsoo.book.config.Configuration;
import kimkwangsoo.book.page.domain.Page;

public class BookDaoImpl implements BookDao {
	private BookMap bookMap;
	
	public BookDaoImpl() {
		this.bookMap = Configuration.getMapper(BookMap.class);
	}
	
	@Override
	public Book getBook(int bookIsbn) {
		return this.bookMap.getBook(bookIsbn);
	}
	
	@Override
	public List<Book> getBooks(Page page) {
		return this.bookMap.getBooks(page);
	}
	
	@Override
	public List<Book> searchBooks(Page page) {
		return this.bookMap.searchBooks(page);
	}
	
	@Override
	public int addBook(Book book) {
		return this.bookMap.addBook(book);
	}
	
	@Override
	public void updateBook(Book book) {
		this.bookMap.updateBook(book);
	}
	
	@Override
	public void updateBookStatus(int bookIsbn) {
		this.bookMap.updateBookStatus(bookIsbn);
	}
	
	@Override
	public void deleteBook(int bookIsbn) {
		this.bookMap.deleteBook(bookIsbn);
	}
}
