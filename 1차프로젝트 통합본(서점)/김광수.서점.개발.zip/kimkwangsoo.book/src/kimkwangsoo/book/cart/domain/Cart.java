package kimkwangsoo.book.cart.domain;

import java.util.List;

import kimkwangsoo.book.book.domain.Book;

public class Cart {
	private int cartNum;
	private String userId;
	private int bookIsbn;
	private int bookQuan;
	private List<Book> books;
	
	public int getCartNum() {
		return cartNum;
	}

	public void setCartNum(int cartNum) {
		this.cartNum = cartNum;
	}

	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public int getBookIsbn() {
		return bookIsbn;
	}
	
	public void setBookIsbn(int bookIsbn) {
		this.bookIsbn = bookIsbn;
	}

	public int getBookQuan() {
		return bookQuan;
	}

	public void setBookQuan(int bookQuan) {
		this.bookQuan = bookQuan;
	}

	public List<Book> getBooks() {
		return books;
	}

	public void setBooks(List<Book> books) {
		this.books = books;
	}
	
	public String toString() {
		return cartNum + " " + userId + " " + bookIsbn + " " + bookQuan + " " + books;
	}
}
