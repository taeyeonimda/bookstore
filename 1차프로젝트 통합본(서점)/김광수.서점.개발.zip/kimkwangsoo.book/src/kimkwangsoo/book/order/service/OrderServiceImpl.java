package kimkwangsoo.book.order.service;

import java.util.List;

import kimkwangsoo.book.order.dao.OrderDao;
import kimkwangsoo.book.order.dao.OrderDaoImpl;
import kimkwangsoo.book.order.domain.Order;
import kimkwangsoo.book.page.domain.Page;

public class OrderServiceImpl implements OrderService {
	private OrderDao orderDao;
	
	public OrderServiceImpl() {
		this.orderDao = new OrderDaoImpl();
	}
	
	@Override
	public Order getOrder(int orderNum) {
		return this.orderDao.getOrder(orderNum);
	}
	
	@Override
	public List<Order> getOrders(Page page) {
		return this.orderDao.getOrders(page);
	}
	
	@Override
	public void addOrder(Order order) {
		this.orderDao.addOrder(order);
	}
}
