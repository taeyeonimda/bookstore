package kimkwangsoo.book.page.domain;

public class Page {
	private int currentPage;
	private int rowCnt;
	private String userId;
	private String words;
	
	public Page() {
		this(1, 4, "default");
	}
	
	public Page(int currentPage) {
		this(currentPage, 4, "default");
	}
	
	public Page(int currentPage, int rowCnt) {
		this.currentPage = currentPage;
		this.rowCnt = rowCnt;
	}
	
	public Page(int currentPage, int rowCnt, String str) {
		this.currentPage = currentPage;
		this.rowCnt = rowCnt;
		this.userId = str;
		this.words = str;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getRowCnt() {
		return rowCnt;
	}

	public void setRowCnt(int rowCnt) {
		this.rowCnt = rowCnt;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getWords() {
		return words;
	}

	public void setWords(String words) {
		this.words = words;
	}
}
