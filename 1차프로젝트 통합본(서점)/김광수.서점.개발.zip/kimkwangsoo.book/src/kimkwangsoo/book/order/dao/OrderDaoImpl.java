package kimkwangsoo.book.order.dao;

import java.util.List;

import kimkwangsoo.book.config.Configuration;
import kimkwangsoo.book.order.dao.map.OrderMap;
import kimkwangsoo.book.order.domain.Order;
import kimkwangsoo.book.page.domain.Page;

public class OrderDaoImpl implements OrderDao {
	private OrderMap orderMap;
	
	public OrderDaoImpl() {
		this.orderMap = Configuration.getMapper(OrderMap.class);
	}
	
	@Override
	public Order getOrder(int orderNum) {
		return this.orderMap.getOrder(orderNum);
	}
	
	@Override
	public List<Order> getOrders(Page page) {
		return this.orderMap.getOrders(page);
	}
	
	@Override
	public void addOrder(Order order) {
		this.orderMap.addOrder(order);
	}
}
