package kimkwangsoo.book.order.service;

import java.util.List;

import kimkwangsoo.book.order.domain.Order;
import kimkwangsoo.book.page.domain.Page;

public interface OrderService {
	Order getOrder(int orderNum);
	List<Order> getOrders(Page page);
	void addOrder(Order order);
}
