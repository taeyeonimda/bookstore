package kimkwangsoo.book.user.dao;

import java.util.List;

import kimkwangsoo.book.page.domain.Page;
import kimkwangsoo.book.user.domain.User;

public interface UserDao {
	User getUser(String userId);
	List<User> getUsers(Page page);
	void addUser(User user);
	void updateUser(User user);
	void deleteUser(User user);
}
